import 'dart:developer';

import 'package:c14190003_01/dataClass/dcPost.dart';
import 'package:c14190003_01/pages/details.dart';
import 'package:c14190003_01/pages/liked.dart';
import 'package:c14190003_01/services/apiServices.dart';
import 'package:c14190003_01/services/dbServices.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

import 'firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MyApp(),
    ),
  );
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  Service serviceAPI = Service();
  //variable future untuk mengambil data dari json
  late Future<List<cPost>> listData;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    listData = serviceAPI.getAllData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("HomePage"),
      ),
      body: Column(
        children: [
          // Expanded(
          //   child: Container(
          //     child: FutureBuilder<List<cPost>>(
          //       future: listData,
          //       builder: (context, snapshot) {
          //         if (snapshot.hasData) {
          //           List<cPost> isiData = snapshot.data!;
          //           return ListView.builder(
          //             itemCount: isiData.length,
          //             itemBuilder: (context, index) {
          //               return Card(
          //                 child: ListTile(
          //                   title: Text(isiData[index].ctitle),
          //                   leading: CircleAvatar(
          //                     backgroundImage:
          //                         NetworkImage(isiData[index].cthumbnail),
          //                   ),
          //                   subtitle: Text(isiData[index].cpubDate),
          //                   onTap: () {
          //                     //showData(isiData[index].cid);
          //                   },
          //                   onLongPress: () {
          //                     //untuk add data ke like
          //                   },
          //                 ),
          //               );
          //             },
          //           );
          //         } else if (snapshot.hasError) {
          //           return Text("${snapshot.error}");
          //         }
          //         return const CircularProgressIndicator();
          //       },
          //     ),
          //   ),
          // ),
          Expanded(
            child: Container(
              child: ListView.builder(
                itemCount: cPost.data.length,
                itemBuilder: (BuildContext context, int index) {
                  return Card(
                    child: ListTile(
                      title: Text(cPost.data[index].ctitle),
                      leading: CircleAvatar(
                          backgroundImage:
                              NetworkImage(cPost.data[index].cthumbnail)),
                      subtitle: Text(cPost.data[index].cpubDate),
                      onLongPress: () {
                        //untuk add data ke like database firestore
                        final dt = cPost(
                            ctitle: cPost.data[index].ctitle,
                            cpubDate: cPost.data[index].cpubDate,
                            cdescription: cPost.data[index].cdescription,
                            cthumbnail: cPost.data[index].cthumbnail,
                            clink: cPost.data[index].clink);
                        DatabaseLikedPost.addLikeData(post: dt);
                      },
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    details(Post: cPost.data[index])));
                      },
                    ),
                  );
                },
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.fromLTRB(8, 8, 8, 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                FloatingActionButton(
                  onPressed: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => liked()));
                  },
                  backgroundColor: Colors.green,
                  child: const Icon(Icons.add),
                ),
                FloatingActionButton(
                  onPressed: () {},
                  backgroundColor: Colors.green,
                  child: const Icon(Icons.book),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
