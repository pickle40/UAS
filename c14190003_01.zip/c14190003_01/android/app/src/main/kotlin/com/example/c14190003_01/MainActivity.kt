package com.example.c14190003_01

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
